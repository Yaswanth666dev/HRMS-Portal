import React from 'react';

const Navbar = () => (
  <div className="navbar">
    <p>Welcome, Admin</p>
  </div>
);

export default Navbar;
