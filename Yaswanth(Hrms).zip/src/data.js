const employees = [
  { id: 1, name: "Yaswanth Babu", email: "yaswanth@example.com", department: "Engineering" },
  { id: 2, name: "Asha Reddy", email: "asha@example.com", department: "HR" },
  { id: 3, name: "Ravi Kumar", email: "ravi@example.com", department: "Finance" },
  { id: 4, name: "Divya Sharma", email: "divya@example.com", department: "Marketing" },
  { id: 5, name: "Suresh K", email: "suresh@example.com", department: "Operations" },
  { id: 6, name: "Meena Joseph", email: "meena@example.com", department: "Sales" },
  { id: 7, name: "Anil R", email: "anil@example.com", department: "IT Support" },
  { id: 8, name: "Sneha Das", email: "sneha@example.com", department: "Design" },
  { id: 9, name: "Karthik N", email: "karthik@example.com", department: "Product" },
  { id: 10, name: "Lakshmi Rao", email: "lakshmi@example.com", department: "Admin" }
];
